class GlobalizationUtil:
    @staticmethod
    def get_language():
        language = "en"
        return language
