******************************************
## Welcome to `ibm-watsonx-orchestrate`
******************************************

``ibm-watsonx-orchestrate`` is a library that allows to work with watsonx.orchestrate service.

==========================================

## How to build installable python package
Run `<project root>/build.sh`
